/*
  # Adicionar tabela de mensagens para histórico completo

  1. New Tables
    - `mensagens`
      - `id` (uuid, primary key) - Unique message ID
      - `telefone` (text) - Customer phone number
      - `mensagem` (text) - Message content
      - `direcao` (text) - Message direction (entrada/saida)
      - `tipo` (text) - Message type (texto, arquivo, imagem, etc)
      - `processada` (boolean) - Whether message was processed by AI
      - `resposta_ia` (text) - AI response if applicable
      - `created_at` (timestamptz) - Message timestamp

  2. Security
    - Enable RLS on mensagens table
    - Add policies for authenticated access and webhook insertion
    - Create indexes for optimal query performance
*/

CREATE TABLE IF NOT EXISTS mensagens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  telefone text NOT NULL,
  mensagem text NOT NULL,
  direcao text NOT NULL DEFAULT 'entrada',
  tipo text DEFAULT 'texto',
  processada boolean DEFAULT false,
  resposta_ia text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_mensagens_telefone ON mensagens(telefone);
CREATE INDEX IF NOT EXISTS idx_mensagens_direcao ON mensagens(direcao);
CREATE INDEX IF NOT EXISTS idx_mensagens_created_at ON mensagens(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_mensagens_processada ON mensagens(processada);

ALTER TABLE mensagens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public insert for webhook"
  ON mensagens FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view messages"
  ON mensagens FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can update messages"
  ON mensagens FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete messages"
  ON mensagens FOR DELETE
  TO authenticated
  USING (true);