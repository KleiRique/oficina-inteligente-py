/*
  # Oficina Inteligente - Database Schema

  1. New Tables
    - `conversas` (conversations)
      - `id` (uuid, primary key) - Unique conversation message ID
      - `telefone` (text) - Customer phone number
      - `mensagem` (text) - Conversation message (both customer and AI)
      - `created_at` (timestamptz) - Message timestamp
    
    - `lojas` (stores)
      - `id` (uuid, primary key) - Store ID
      - `nome` (text) - Store name
      - `endereco` (text) - Store address
      - `telefone` (text) - Store phone
      - `created_at` (timestamptz) - Creation timestamp
    
    - `configuracoes` (configurations)
      - `id` (uuid, primary key) - Config ID
      - `chave` (text, unique) - Configuration key
      - `valor` (text) - Configuration value
      - `descricao` (text) - Configuration description
      - `created_at` (timestamptz) - Creation timestamp
    
    - `pedidos` (orders)
      - `id` (uuid, primary key) - Order ID
      - `telefone` (text) - Customer phone
      - `descricao` (text) - Order description
      - `status` (text) - Order status (pending, in_progress, completed)
      - `valor` (numeric) - Order value
      - `created_at` (timestamptz) - Creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated access to manage data
    - Public read access for conversas to allow webhook processing

  3. Notes
    - All tables use UUID for primary keys
    - Timestamps use timestamptz for timezone awareness
    - Default values ensure data consistency
*/

-- Create conversas table
CREATE TABLE IF NOT EXISTS conversas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  telefone text NOT NULL,
  mensagem text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_conversas_telefone ON conversas(telefone);
CREATE INDEX IF NOT EXISTS idx_conversas_created_at ON conversas(created_at DESC);

-- Create lojas table
CREATE TABLE IF NOT EXISTS lojas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  endereco text DEFAULT '',
  telefone text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create configuracoes table
CREATE TABLE IF NOT EXISTS configuracoes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chave text UNIQUE NOT NULL,
  valor text NOT NULL,
  descricao text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create pedidos table
CREATE TABLE IF NOT EXISTS pedidos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  telefone text NOT NULL,
  descricao text NOT NULL,
  status text DEFAULT 'pending',
  valor numeric(10, 2) DEFAULT 0.00,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pedidos_telefone ON pedidos(telefone);
CREATE INDEX IF NOT EXISTS idx_pedidos_status ON pedidos(status);

-- Enable Row Level Security
ALTER TABLE conversas ENABLE ROW LEVEL SECURITY;
ALTER TABLE lojas ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE pedidos ENABLE ROW LEVEL SECURITY;

-- Policies for conversas (allow public insert for webhook, authenticated read/update)
CREATE POLICY "Allow public insert for webhook"
  ON conversas FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view all conversations"
  ON conversas FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can delete conversations"
  ON conversas FOR DELETE
  TO authenticated
  USING (true);

-- Policies for lojas
CREATE POLICY "Authenticated users can view stores"
  ON lojas FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert stores"
  ON lojas FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update stores"
  ON lojas FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policies for configuracoes
CREATE POLICY "Authenticated users can view configurations"
  ON configuracoes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert configurations"
  ON configuracoes FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update configurations"
  ON configuracoes FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policies for pedidos
CREATE POLICY "Authenticated users can view all orders"
  ON pedidos FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow public insert for webhook orders"
  ON pedidos FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update orders"
  ON pedidos FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);