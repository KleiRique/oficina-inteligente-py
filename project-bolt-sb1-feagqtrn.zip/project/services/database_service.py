import logging
from supabase import Client
from datetime import datetime
from typing import Optional, List

logger = logging.getLogger(__name__)

async def save_message(
    supabase: Client,
    phone: str,
    message: str,
    direction: str = "entrada",
    processed: bool = False,
    message_type: str = "texto"
) -> bool:
    """
    Salva mensagem no banco de dados.

    Args:
        supabase: Cliente Supabase
        phone: Número de telefone
        message: Conteúdo da mensagem
        direction: "entrada" ou "saida"
        processed: Se foi processada por IA
        message_type: Tipo de mensagem (texto, arquivo, imagem)

    Returns:
        True se salva com sucesso, False caso contrário
    """
    try:
        supabase.table("mensagens").insert({
            "telefone": phone,
            "mensagem": message,
            "direcao": direction,
            "tipo": message_type,
            "processada": processed
        }).execute()

        logger.info(f"✅ Mensagem salva para {phone} ({direction})")
        return True

    except Exception as e:
        logger.error(f"❌ Erro ao salvar mensagem: {str(e)}")
        return False

async def get_conversation_history(
    supabase: Client,
    phone: str,
    limit: int = 10
) -> List[dict]:
    """
    Recupera histórico de conversa de um cliente.

    Args:
        supabase: Cliente Supabase
        phone: Número de telefone
        limit: Número máximo de mensagens a retornar

    Returns:
        Lista de mensagens do histórico
    """
    try:
        response = supabase.table("mensagens")\
            .select("*")\
            .eq("telefone", phone)\
            .order("created_at", desc=True)\
            .limit(limit)\
            .execute()

        if response.data:
            history = list(reversed(response.data))
            logger.info(f"✅ Histórico recuperado para {phone} ({len(history)} mensagens)")
            return history

        logger.info(f"ℹ️ Nenhum histórico encontrado para {phone}")
        return []

    except Exception as e:
        logger.error(f"❌ Erro ao recuperar histórico: {str(e)}")
        return []

async def get_customer_orders(
    supabase: Client,
    phone: str
) -> List[dict]:
    """
    Recupera pedidos de um cliente.

    Args:
        supabase: Cliente Supabase
        phone: Número de telefone

    Returns:
        Lista de pedidos
    """
    try:
        response = supabase.table("pedidos")\
            .select("*")\
            .eq("telefone", phone)\
            .order("created_at", desc=True)\
            .execute()

        logger.info(f"✅ Pedidos recuperados para {phone} ({len(response.data)} pedidos)")
        return response.data

    except Exception as e:
        logger.error(f"❌ Erro ao recuperar pedidos: {str(e)}")
        return []
