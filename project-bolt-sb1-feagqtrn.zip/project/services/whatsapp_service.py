import httpx
import logging

logger = logging.getLogger(__name__)

async def send_whatsapp_message(phone: str, message: str, token: str, sender: str) -> bool:
    """
    Envia mensagem via Uazapi para WhatsApp.

    Args:
        phone: Número de telefone do destinatário
        message: Conteúdo da mensagem
        token: Token de autenticação do Uazapi
        sender: Número de telefone remetente

    Returns:
        True se enviada com sucesso, False caso contrário
    """
    try:
        url = "https://api.uazapi.com/message/sendText"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }
        payload = {
            "to": phone,
            "text": message,
            "sender": sender
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=payload, headers=headers, timeout=10.0)
            response.raise_for_status()

        logger.info(f"✅ Mensagem enviada para {phone} via Uazapi")
        return True

    except httpx.HTTPStatusError as e:
        logger.error(f"❌ Erro HTTP ao enviar mensagem para {phone}: {e.response.text}")
        return False
    except httpx.RequestError as e:
        logger.error(f"❌ Erro de conexão ao enviar mensagem para {phone}: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"❌ Erro inesperado ao enviar mensagem para {phone}: {str(e)}")
        return False
