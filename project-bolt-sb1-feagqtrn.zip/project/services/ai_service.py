import logging
from openai import AsyncOpenAI
from typing import Optional

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """Você é um atendente técnico especializado da Oficina Inteligente.

Seu objetivo é:
- Responder dúvidas sobre serviços de reparo automotivo
- Ajudar com agendamentos de serviços
- Fornecer informações sobre manutenção preventiva
- Orientar sobre diagnósticos básicos
- Manter um tom profissional, educado e prático

Sempre mantenha a conversa breve e direta. Se o cliente precisar falar com um especialista, ofereça essa opção.
Nunca prometa mais do que a oficina pode entregar. Sempre confirme disponibilidade antes de agendar."""

async def generate_ai_response(
    openai_client: AsyncOpenAI,
    message: str,
    history: Optional[list] = None,
    max_tokens: int = 500
) -> str:
    """
    Gera resposta automática usando GPT-4o-mini.

    Args:
        openai_client: Cliente AsyncOpenAI configurado
        message: Mensagem do cliente
        history: Histórico de conversas anteriores
        max_tokens: Número máximo de tokens na resposta

    Returns:
        Resposta gerada pela IA
    """
    try:
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT}
        ]

        if history:
            for msg in history[-5:]:
                messages.append({
                    "role": "user" if msg["direcao"] == "entrada" else "assistant",
                    "content": msg["mensagem"]
                })

        messages.append({"role": "user", "content": message})

        response = await openai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0.7,
            max_tokens=max_tokens
        )

        ai_message = response.choices[0].message.content
        logger.info(f"✅ Resposta IA gerada com sucesso")
        return ai_message

    except Exception as e:
        logger.error(f"❌ Erro ao gerar resposta IA: {str(e)}")
        return "Desculpe, tive um problema ao processar sua mensagem. Por favor, tente novamente."
