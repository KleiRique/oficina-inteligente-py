from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import httpx
import os
import logging
from datetime import datetime
from openai import AsyncOpenAI
from supabase import create_client, Client
from dotenv import load_dotenv

load_dotenv()

from services.whatsapp_service import send_whatsapp_message
from services.ai_service import generate_ai_response
from services.database_service import save_message, get_conversation_history

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
UAZAPI_TOKEN = os.getenv("UAZAPI_TOKEN")
UAZAPI_NUMERO = os.getenv("UAZAPI_NUMERO")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
openai_client = AsyncOpenAI(api_key=OPENAI_API_KEY)

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("✅ Servidor iniciado - Oficina Inteligente API")
    yield
    logger.info("❌ Servidor encerrado")

app = FastAPI(
    title="Oficina Inteligente API",
    description="Backend inteligente para atendimento via WhatsApp",
    version="1.0.0",
    lifespan=lifespan
)

@app.post("/webhook")
async def receber_mensagem(request: Request):
    """
    Recebe mensagens do Uazapi, processa com IA e envia resposta.
    """
    try:
        data = await request.json()
        logger.info(f"📩 Webhook recebido")

        phone = data.get("data", {}).get("key", {}).get("remoteJid", "").replace("@s.whatsapp.net", "")
        message_text = data.get("data", {}).get("message", {}).get("conversation", "")

        if not phone or not message_text:
            logger.warning("⚠️ Mensagem inválida ou incompleta")
            return {"status": "ignored", "reason": "Mensagem inválida"}

        logger.info(f"📱 Telefone: {phone}")

        await save_message(
            supabase=supabase,
            phone=phone,
            message=message_text,
            direction="entrada",
            processed=False
        )

        history = await get_conversation_history(supabase, phone)

        ai_response = await generate_ai_response(
            openai_client=openai_client,
            message=message_text,
            history=history
        )

        await save_message(
            supabase=supabase,
            phone=phone,
            message=ai_response,
            direction="saida",
            processed=True
        )

        await send_whatsapp_message(
            phone=phone,
            message=ai_response,
            token=UAZAPI_TOKEN,
            sender=UAZAPI_NUMERO
        )

        logger.info(f"✅ Resposta enviada para {phone}")
        return {"status": "success", "phone": phone, "message_sent": True}

    except ValueError as e:
        logger.error(f"❌ Erro de validação: {str(e)}")
        return JSONResponse({"error": str(e)}, status_code=400)
    except httpx.HTTPError as e:
        logger.error(f"❌ Erro HTTP: {str(e)}")
        return JSONResponse({"error": "Erro ao comunicar com Uazapi"}, status_code=502)
    except Exception as e:
        logger.error(f"❌ Erro inesperado: {str(e)}", exc_info=True)
        return JSONResponse({"error": "Erro interno do servidor"}, status_code=500)

@app.get("/")
async def home():
    return {
        "message": "🚀 Servidor da Oficina Inteligente ativo!",
        "timestamp": datetime.now().isoformat(),
        "status": "online"
    }

@app.get("/health")
async def health():
    try:
        supabase.table("configuracoes").select("*").limit(1).execute()
        db_status = "healthy"
    except Exception as e:
        logger.error(f"Erro ao conectar ao banco: {str(e)}")
        db_status = "unhealthy"

    return {
        "status": "healthy",
        "database": db_status,
        "openai": "configured" if OPENAI_API_KEY else "not configured",
        "uazapi": "configured" if UAZAPI_TOKEN else "not configured",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/conversas/{telefone}")
async def listar_conversas(telefone: str, limit: int = 50):
    try:
        response = supabase.table("mensagens")\
            .select("*")\
            .eq("telefone", telefone)\
            .order("created_at", desc=True)\
            .limit(limit)\
            .execute()

        return {"telefone": telefone, "total": len(response.data), "mensagens": response.data}
    except Exception as e:
        logger.error(f"Erro ao buscar conversas: {str(e)}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/pedidos/{telefone}")
async def listar_pedidos(telefone: str):
    try:
        response = supabase.table("pedidos")\
            .select("*")\
            .eq("telefone", telefone)\
            .order("created_at", desc=True)\
            .execute()

        return {"telefone": telefone, "pedidos": response.data}
    except Exception as e:
        logger.error(f"Erro ao buscar pedidos: {str(e)}")
        return JSONResponse({"error": str(e)}, status_code=500)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
