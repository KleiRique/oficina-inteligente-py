import os
from dotenv import load_dotenv

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
UAZAPI_TOKEN = os.getenv("UAZAPI_TOKEN")
UAZAPI_NUMERO = os.getenv("UAZAPI_NUMERO")

if not all([SUPABASE_URL, SUPABASE_KEY, OPENAI_API_KEY, UAZAPI_TOKEN, UAZAPI_NUMERO]):
    raise ValueError("Variáveis de ambiente não configuradas corretamente")
